/**
 * Twitter/X Content Script
 *
 * 功能：
 * 1. 检测登录状态
 * 2. 同步 Cookie 到服务器
 * 3. 自动发布推文
 * 4. 获取运营数据
 */

(function() {
    'use strict';

    const PLATFORM = 'twitter';

    console.log('[Prome Twitter] Content script loaded on:', window.location.href);

    // ========== 工具函数 ==========

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function isLoggedIn() {
        // 检查是否有登录相关的 DOM 元素
        const composeBtn = document.querySelector('[data-testid="SideNav_NewTweet_Button"]') ||
                          document.querySelector('[aria-label="Post"]') ||
                          document.querySelector('[aria-label="Compose"]');

        // 检查 URL 是否是登录页
        const isLoginPage = window.location.href.includes('/login') ||
                           window.location.href.includes('/i/flow/login');

        return composeBtn !== null && !isLoginPage;
    }

    function getUserInfo() {
        try {
            // 尝试从页面获取用户信息
            const userAvatar = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"] img');
            const userName = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"] span');

            return {
                avatar: userAvatar?.src || null,
                name: userName?.textContent || null,
            };
        } catch (e) {
            return null;
        }
    }

    // ========== Cookie 同步 ==========

    async function syncCookiesToServer() {
        console.log('[Prome Twitter] Syncing cookies to server...');

        try {
            // 通过 background script 获取 cookies
            const response = await chrome.runtime.sendMessage({
                type: 'GET_TWITTER_COOKIES'
            });

            if (response && response.cookies) {
                console.log('[Prome Twitter] Got', response.cookies.length, 'cookies');

                // 发送到 Prome 服务器
                const userId = await getPromeUserId();
                if (!userId) {
                    console.warn('[Prome Twitter] No Prome user ID found');
                    return { success: false, error: 'No user ID' };
                }

                // 通过 background script 发送到服务器
                const syncResult = await chrome.runtime.sendMessage({
                    type: 'SYNC_TWITTER_COOKIES_TO_SERVER',
                    userId: userId,
                    cookies: response.cookies,
                    userAgent: navigator.userAgent,
                });

                return syncResult;
            }
        } catch (e) {
            console.error('[Prome Twitter] Cookie sync error:', e);
            return { success: false, error: e.message };
        }
    }

    async function getPromeUserId() {
        try {
            const result = await chrome.storage.local.get(['promeUserId', 'supabaseUserId']);
            return result.supabaseUserId || result.promeUserId || null;
        } catch (e) {
            return null;
        }
    }

    // ========== 发布推文 ==========

    async function publishTweet(text, mediaUrls = []) {
        console.log('[Prome Twitter] Publishing tweet:', text.substring(0, 50) + '...');

        try {
            // 确保在首页或可以发推的页面
            if (!window.location.href.includes('/home') && !window.location.href.includes('/compose')) {
                window.location.href = 'https://x.com/home';
                await sleep(3000);
            }

            // 查找并点击发推按钮
            const composeBtn = document.querySelector('[data-testid="SideNav_NewTweet_Button"]') ||
                              document.querySelector('[aria-label="Post"]');

            if (composeBtn) {
                composeBtn.click();
                await sleep(1000);
            }

            // 查找输入框
            const tweetInput = document.querySelector('[data-testid="tweetTextarea_0"]') ||
                              document.querySelector('[role="textbox"]') ||
                              document.querySelector('[contenteditable="true"]');

            if (!tweetInput) {
                throw new Error('Could not find tweet input');
            }

            // 输入文本
            tweetInput.focus();
            await sleep(200);

            // 使用 execCommand 或直接设置 innerHTML
            document.execCommand('insertText', false, text);
            await sleep(500);

            // TODO: 处理媒体上传

            // 点击发送按钮
            const postBtn = document.querySelector('[data-testid="tweetButton"]') ||
                           document.querySelector('[data-testid="tweetButtonInline"]');

            if (!postBtn) {
                throw new Error('Could not find post button');
            }

            postBtn.click();
            await sleep(2000);

            console.log('[Prome Twitter] Tweet posted successfully');
            return { success: true };

        } catch (e) {
            console.error('[Prome Twitter] Publish error:', e);
            return { success: false, error: e.message };
        }
    }

    // ========== 消息监听 ==========

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        console.log('[Prome Twitter] Received message:', message.type);

        switch (message.type) {
            case 'CHECK_TWITTER_LOGIN':
                sendResponse({
                    loggedIn: isLoggedIn(),
                    userInfo: getUserInfo(),
                    url: window.location.href,
                });
                break;

            case 'SYNC_TWITTER_COOKIES':
                syncCookiesToServer().then(sendResponse);
                return true; // Async response

            case 'PUBLISH_TWEET':
                publishTweet(message.text, message.mediaUrls).then(sendResponse);
                return true; // Async response

            case 'GET_TWITTER_ANALYTICS':
                // TODO: 实现获取分析数据
                sendResponse({ success: false, error: 'Not implemented yet' });
                break;

            default:
                sendResponse({ success: false, error: 'Unknown message type' });
        }
    });

    // ========== 初始化 ==========

    async function init() {
        // 等待页面加载
        await sleep(2000);

        const loggedIn = isLoggedIn();
        console.log('[Prome Twitter] Login status:', loggedIn);

        if (loggedIn) {
            // 自动同步 Cookie（如果用户已登录）
            const userId = await getPromeUserId();
            if (userId) {
                console.log('[Prome Twitter] User logged in, auto-syncing cookies...');
                await syncCookiesToServer();
            }

            // 检查是否有待发布的推文
            await checkPendingPublish();
        }

        // 通知 background script 页面已加载
        chrome.runtime.sendMessage({
            type: 'TWITTER_PAGE_LOADED',
            loggedIn: loggedIn,
            url: window.location.href,
        });
    }

    // ========== 检查待发布任务 ==========
    async function checkPendingPublish() {
        try {
            const result = await chrome.storage.local.get(['pendingTwitterPublish']);
            const pending = result.pendingTwitterPublish;

            if (pending && pending.text) {
                console.log('[Prome Twitter] Found pending publish task:', pending);

                // 清除待发布数据
                await chrome.storage.local.remove(['pendingTwitterPublish']);

                // 等待页面完全加载
                await sleep(2000);

                // 执行发布
                const publishResult = await publishTweet(pending.text, pending.mediaUrls || []);

                // 通知结果
                chrome.runtime.sendMessage({
                    type: 'TWITTER_PUBLISH_RESULT',
                    taskId: pending.taskId,
                    success: publishResult.success,
                    error: publishResult.error
                });
            }
        } catch (e) {
            console.error('[Prome Twitter] Check pending publish error:', e);
        }
    }

    // 启动
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
